package License;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:45 PM
 */
public class truckLicense {

	public truckLicense(){

	}

	public void finalize() throws Throwable {

	}
}//end truckLicense