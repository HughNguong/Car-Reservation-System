package License;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:39 PM
 */
public class carLicense {

	public carLicense(){

	}

	public void finalize() throws Throwable {

	}
}//end carLicense