package Contract;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:43 PM
 */
public class rentalContract extends contract {

	public insuranceContract m_insuranceContract;

	public rentalContract(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	
}//end rentalContract