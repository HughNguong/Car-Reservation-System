package Contract;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 6:06:23 PM
 */
public class insuranceContract extends contract {

	public insuranceContract(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end insuranceContract