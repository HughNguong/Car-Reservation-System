package Contract;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:44 PM
 */
public class reservationContract extends contract {

	public rentalContract m_rentalContract;

	public reservationContract(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end reservationContract