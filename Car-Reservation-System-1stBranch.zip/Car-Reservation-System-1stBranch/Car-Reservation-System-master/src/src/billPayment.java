package src;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:35 PM
 */
public class billPayment {

	private int totalAmount;

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public billPayment(){

	}

	public void finalize() throws Throwable {

	}
}//end billPlayment