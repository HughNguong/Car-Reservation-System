package Vehicle;

import License.carLicense;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:46 PM
 */
public class van extends truck {

	public carLicense m_carLicense;

	public van(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end van