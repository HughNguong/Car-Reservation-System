package Vehicle;

import License.truckLicense;

/**
 * @author Tuan Nguyen
 * @version 1.0
 * @created 26-Nov-2018 5:27:45 PM
 */
public class truck extends vehicle {

	public truckLicense m_truckLicense;

	public truck(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}//end truck